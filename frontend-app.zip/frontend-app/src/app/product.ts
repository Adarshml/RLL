// map to entity class 
export class Product {

    constructor(public pid:number,
        public pname:string,
        public price:number,
        public url:string,
        public type:string,
        public description:string){}
}
